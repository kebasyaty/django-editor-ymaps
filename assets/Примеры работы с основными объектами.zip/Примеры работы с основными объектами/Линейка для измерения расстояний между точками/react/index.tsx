import type {LngLat} from '@yandex/ymaps3-types';
import type {RenderPointArgs, RulerType, RulerCommonState, RulerGeometry} from '@yandex/ymaps3-types/modules/ruler';
import {FEATURE_STYLE, formatArea, formatDistance, randomColor} from '../common';
import {LOCATION, RULER_COORDINATES} from '../variables';

window.map = null;

main();
async function main() {
    // For each object in the JS API, there is a React counterpart
    // To use the React version of the API, include the module @yandex/ymaps3-reactify
    const [ymaps3React] = await Promise.all([ymaps3.import('@yandex/ymaps3-reactify'), ymaps3.ready]);
    const reactify = ymaps3React.reactify.bindTo(React, ReactDOM);
    const {
        YMap,
        YMapDefaultSchemeLayer,
        YMapDefaultFeaturesLayer,
        YMapMarker,
        YMapControls,
        YMapControl,
        YMapControlButton
    } = reactify.module(ymaps3);
    const {YMapRuler} = reactify.module(await ymaps3.import('@yandex/ymaps3-ruler'));

    const RulerPoint = (props: RenderPointArgs) => {
        const {measurements, index, coordinates, editable, totalCount, source} = props.state;

        const [showBalloon, setShowBalloon] = React.useState(false);
        const backgroundColor = React.useRef(undefined);
        backgroundColor.current ??= randomColor();

        const label = React.useMemo(() => {
            return measurements.type === 'planimeter'
                ? formatArea(measurements.area)
                : formatDistance(measurements.distance);
        }, [measurements]);

        const showLastBalloon = React.useMemo(() => {
            return index === totalCount - 1;
        }, [index, totalCount]);

        const onClick = React.useCallback(() => {
            setShowBalloon((value) => !value);
        }, []);

        const onDelete = React.useCallback((event) => {
            event.stopPropagation();
            props.onDelete();
        }, []);

        return (
            <>
                <YMapMarker
                    coordinates={coordinates}
                    zIndex={21}
                    source={source}
                    draggable={editable}
                    onDragMove={props.onDragMove}
                    onFastClick={onClick}
                >
                    <div className="point" style={{backgroundColor: backgroundColor.current}}></div>
                </YMapMarker>
                {(showLastBalloon || showBalloon) && (
                    <YMapMarker coordinates={coordinates} zIndex={20} source={source}>
                        <div className="balloon">
                            <span>{label}</span>
                            <button onClick={onDelete} className="button">
                                delete
                            </button>
                        </div>
                    </YMapMarker>
                )}
            </>
        );
    };

    function App() {
        const [location, setLocation] = React.useState(LOCATION);
        const [geometry] = React.useState<RulerGeometry>({style: FEATURE_STYLE});
        const [type, setType] = React.useState<RulerType>('ruler');
        const [editable, setEditable] = React.useState(true);
        const [commonInfo, setCommonInfo] = React.useState('');

        const setRulerType = React.useCallback(() => setType('ruler'), []);
        const setPlanimeterType = React.useCallback(() => setType('planimeter'), []);

        const enableRuler = React.useCallback(() => setEditable(true), []);
        const disableRuler = React.useCallback(() => setEditable(false), []);

        const onRender = React.useCallback((params: RenderPointArgs) => {
            return <RulerPoint {...params} />;
        }, []);
        const onUpdate = React.useCallback(({measurements}: RulerCommonState) => {
            setCommonInfo(
                measurements.type === 'ruler'
                    ? `Total distance: ${formatDistance(measurements.totalDistance)}`
                    : `Area: ${formatArea(measurements.area)}`
            );
        }, []);

        return (
            // Initialize the map and pass initialization parameters
            <YMap location={location} showScaleInCopyrights={true} ref={(x) => (map = x)}>
                {/* Add a map scheme layer */}
                <YMapDefaultSchemeLayer />
                <YMapDefaultFeaturesLayer />

                <YMapControls position="top right">
                    <YMapControlButton onClick={setRulerType}>
                        <span className="ruler-button">ruler</span>
                    </YMapControlButton>
                    <YMapControlButton onClick={setPlanimeterType}>
                        <span className="planimeter-button">planimeter</span>
                    </YMapControlButton>
                </YMapControls>

                <YMapControls position="top left">
                    <YMapControlButton text="enable" onClick={enableRuler} />
                    <YMapControlButton text="disable" onClick={disableRuler} />
                </YMapControls>

                <YMapControls position="top">
                    <YMapControl>
                        <span className="info">{commonInfo}</span>
                    </YMapControl>
                </YMapControls>

                <YMapRuler
                    points={reactify.useDefault(RULER_COORDINATES)}
                    editable={editable}
                    type={type}
                    point={onRender}
                    onUpdate={onUpdate}
                    geometry={geometry}
                    previewPoint={<div className="preview-point"></div>}
                />
            </YMap>
        );
    }

    ReactDOM.render(
        <React.StrictMode>
            <App />
        </React.StrictMode>,
        document.getElementById('app')
    );
}
