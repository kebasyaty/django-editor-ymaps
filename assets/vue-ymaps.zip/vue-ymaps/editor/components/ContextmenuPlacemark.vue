<!--
-----------------------------------------------
Component for creating and editable Placemarks.
-----------------------------------------------
-->
<template>
  <v-conteiner fluid>
    <!-- Buttons:
     Add information about a geoobject.
     Select Categories and Subcategories. -->
    <v-row class="pb-8">
      <v-col
        cols="12"
        v-for="(icon, index) in icons"
        :key="`action-btn-${index}`"
      >
        <v-btn
          small
          block
          depressed
          :color="colorControlsTheme"
          @click="openDialog(index)"
        >
          <v-icon left :color="colorButtonsTextTheme">{{
            icons[index]
          }}</v-icon>
          {{ $t(`message.${transTitle[index]}`) }}
        </v-btn>
      </v-col>
    </v-row>
    <!-- Select marker icon -->
    <v-row align="center" justify="center">
      <v-col cols="12" class="px-0 pt-3 pb-0 text-center">
        <span
          class="icon-marker"
          @click="openIconCollection()"
          :style="`background-color:${
            $vuetify.theme.dark ? '#616161' : '#EEEEEE'
          }`"
        >
          <img :src="updateIconUrl" alt="Marker Icon" />
        </span>
      </v-col>
    </v-row>
    <!-- Coordinate display - Latitude and Longitude. -->
    <v-row class="pt-5">
      <v-col cols="12" class="py-0">
        <v-text-field
          id="id-djeym-latitude"
          v-model="updateLatitude"
          :label="$t('message.90')"
          hint="-90.0 ... 90.0"
          clearable
          dense
          full-width
          maxlength="19"
          :rules="rulesLatitude()"
          :color="colorControlsTheme"
        ></v-text-field>
      </v-col>
      <v-col cols="12" class="py-0">
        <v-text-field
          id="id-djeym-longitude"
          v-model="updateLongitude"
          :label="$t('message.91')"
          hint="-180.0 ... 180.0"
          clearable
          dense
          full-width
          maxlength="20"
          :rules="rulesLongitude()"
          :color="colorControlsTheme"
        ></v-text-field>
      </v-col>
    </v-row>
  </v-conteiner>
</template>

<script>
import { mapState, mapMutations, mapActions } from "vuex";
import helpers from "@/helpers.js";

export default {
  name: "ContextmenuPlacemark",
  data: () => ({
    icons: ["mdi-information-outline", "mdi-check-circle"],
    transTitle: [101, 102],
  }),
  computed: {
    ...mapState("generalSettings", [
      "colorControlsTheme",
      "colorButtonsTextTheme",
    ]),
    ...mapState("ymap", ["editableGeoobject"]),
    ...mapState(["iconCollection"]),
    ...mapState("contextmenuPlacemark", [
      "iconUrl",
      "category",
      "subcategories",
      "coordinates",
    ]),
    ...mapState("SelectCategories", {
      selectedControls: "controls",
    }),
    ...mapState("geoobjectDataForm", {
      headerDataForm: "header",
      bodyDataForm: "body",
      footerDataForm: "footer",
    }),
    updateIconUrl: {
      get() {
        return this.iconUrl;
      },
      set(url) {
        this.setIconUrl(url);
      },
    },
    updateLatitude: {
      get() {
        return this.coordinates[0];
      },
      set(coord) {
        this.setLatitude(coord);
      },
    },
    updateLongitude: {
      get() {
        return this.coordinates[1];
      },
      set(coord) {
        this.setLongitude(coord);
      },
    },
  },
  methods: {
    ...mapMutations("contextmenuPlacemark", [
      "setPK",
      "setCategory",
      "setSubcategories",
      "setHeader",
      "setBody",
      "setFooter",
      "setIconSlug",
      "setLatitude",
      "setLongitude",
      "setIconUrl",
    ]),
    ...mapMutations("modals", [
      // Controls
      "controlsDialogShow", // Open
      "controlsDialogClose", // Close
      // Simple messages
      "alertSnackbarClose", // Close
    ]),
    ...mapMutations(["setDataAction"]),
    ...mapActions("contextmenuPlacemark", ["restoreDefaults"]),
    // Rules
    rulesLatitude() {
      return [(coord) => helpers.checkLatitude(coord) || this.$t("message.92")];
    },
    rulesLongitude() {
      return [
        (coord) => helpers.checkLongitude(coord) || this.$t("message.92"),
      ];
    },
    // Open Icon list.
    openIconCollection() {
      this.alertSnackbarClose();
      this.controlsDialogShow({
        title: this.$t("message.7"),
        text: "",
        cancelBtn: true,
        saveBtn: false,
        componentIcons: true,
        actionBtnSave: null,
        actionBtnCancel: this.controlsDialogClose,
      });
    },
    // Open a pop-up window to enter information about geoobject.
    openDialog(index) {
      this.alertSnackbarClose();
      switch (index) {
        case 0:
          // Open form to enter information about geoobject.
          this.setDataAction({
            geoType: "placemark",
          });
          this.controlsDialogShow({
            title: this.$t("message.64"),
            text: "",
            cancelBtn: true,
            saveBtn: true,
            componentGeoobjectDataForm: true,
            actionBtnSave: () => {
              this.setHeader(this.headerDataForm);
              this.setBody(this.bodyDataForm);
              this.setFooter(this.footerDataForm);
              if (this.editableGeoobject !== null) {
                this.editableGeoobject.properties.set(
                  "balloonContentHeader",
                  this.headerDataForm,
                );
                this.editableGeoobject.properties.set(
                  "balloonContentBody",
                  this.bodyDataForm,
                );
                this.editableGeoobject.properties.set(
                  "balloonContentFooter",
                  this.footerDataForm,
                );
              }
              this.controlsDialogClose();
            },
            actionBtnCancel: this.controlsDialogClose,
          });
          break;
        case 1:
          // Open Category and Subcategory list.
          this.setDataAction({
            geoType: "placemark",
            category: this.category,
            subcategories: this.subcategories,
          });
          this.controlsDialogShow({
            title: this.$t("message.105"),
            text: "",
            cancelBtn: true,
            saveBtn: true,
            componentCategories: true,
            actionBtnSave: () => {
              this.setCategory(this.selectedControls.category);
              this.setSubcategories(this.selectedControls.subcategories);
              if (this.editableGeoobject !== null) {
                this.editableGeoobject.properties.set(
                  "categoryID",
                  this.category,
                );
                this.editableGeoobject.properties.set(
                  "subCategoryIDs",
                  this.subcategories,
                );
              }
              this.controlsDialogClose();
            },
            actionBtnCancel: this.controlsDialogClose,
          });
          break;
      }
    },
  },
  created() {
    // Updating data
    if (this.editableGeoobject === null) {
      this.restoreDefaults(); // Restore Defaults
    } else {
      this.setPK(this.editableGeoobject.properties.get("id"));
      this.setCategory(this.editableGeoobject.properties.get("categoryID"));
      this.setSubcategories(
        this.editableGeoobject.properties.get("subCategoryIDs"),
      );
      this.setHeader(
        this.editableGeoobject.properties.get("balloonContentHeader"),
      );
      this.setBody(this.editableGeoobject.properties.get("balloonContentBody"));
      this.setFooter(
        this.editableGeoobject.properties.get("balloonContentFooter"),
      );
      const iconSlug = this.editableGeoobject.properties.get("iconSlug");
      this.setIconSlug(iconSlug);
      if (iconSlug !== "djeym-marker-default") {
        this.setIconUrl(
          this.iconCollection.filter((item) => item.slug === iconSlug)[0].url,
        );
      } else {
        this.setIconUrl("/static/djeym/img/center.svg");
      }
      const coords = this.editableGeoobject.geometry.getCoordinates();
      this.setLatitude(coords[0]);
      this.setLongitude(coords[1]);
    }
  },
};
</script>

<style scoped>
.icon-marker {
  width: 84px;
  height: 84px;
  border-radius: 50%;
  z-index: 2;
  cursor: pointer;
  display: inline-block;
}

.icon-marker > img {
  height: 42px;
  display: block;
  margin-top: 24px;
  margin-left: auto;
  margin-right: auto;
}
</style>
