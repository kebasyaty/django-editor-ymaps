import type {DrawingStyle, YMapLocationRequest} from '@yandex/ymaps3-types';

export const LOCATION: YMapLocationRequest = {
    center: [37.623082, 55.75254], // starting position [lng, lat]
    zoom: 9 // starting zoom
};

export const MINIMAP_BOUNDS_STYLE: DrawingStyle = {
    fill: 'rgb(25, 109, 255)',
    fillOpacity: 0.08,
    stroke: [{width: 1, color: '#313133'}]
};
