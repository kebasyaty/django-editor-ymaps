import {LOCATION} from '../variables';

window.map = null;

async function main() {
    const [ymaps3Vue] = await Promise.all([ymaps3.import('@yandex/ymaps3-vuefy'), ymaps3.ready]);
    const vuefy = ymaps3Vue.vuefy.bindTo(Vue);
    const {YMap, YMapDefaultSchemeLayer, YMapControls, YMapScaleControl} = vuefy.module(ymaps3);
    const {YMapZoomControl} = vuefy.module(await ymaps3.import('@yandex/ymaps3-default-ui-theme'));

    const app = Vue.createApp({
        components: {YMap, YMapDefaultSchemeLayer, YMapControls, YMapScaleControl, YMapZoomControl},
        setup() {
            const refMap = (ref) => {
                window.map = ref?.entity;
            };
            return {LOCATION, refMap};
        },
        template: `
            <!--You can display the map scale as part of copyrights-->
            <YMap :location="LOCATION" showScaleInCopyrights :ref="refMap">
                <YMapDefaultSchemeLayer />
                <YMapControls position="right">
                    <YMapZoomControl />
                </YMapControls>

                <!--Or place the scale of the map as a control anywhere on the map-->
                <YMapControls position="bottom left">
                    <YMapScaleControl />
                </YMapControls>
            </YMap>`
    });
    app.mount('#app');
}
main();
