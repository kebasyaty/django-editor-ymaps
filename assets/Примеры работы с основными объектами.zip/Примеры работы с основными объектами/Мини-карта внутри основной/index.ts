import type {YMapMarker} from '@yandex/ymaps3-types';
import type {RenderPointArgs, RulerPointState} from '@yandex/ymaps3-types/modules/ruler';
import {FEATURE_STYLE, formatArea, formatDistance, randomColor} from '../common';
import {LOCATION, RULER_COORDINATES} from '../variables';

window.map = null;

main();
async function main() {
    // Waiting for all api elements to be loaded
    await ymaps3.ready;
    const {
        YMap,
        YMapDefaultSchemeLayer,
        YMapDefaultFeaturesLayer,
        YMapMarker,
        YMapControls,
        YMapControl,
        YMapControlButton
    } = ymaps3;
    const {YMapRuler} = await ymaps3.import('@yandex/ymaps3-ruler');
    // Initialize the map
    map = new YMap(
        // Pass the link to the HTMLElement of the container
        document.getElementById('app'),
        // Pass the map initialization parameters
        {location: LOCATION, showScaleInCopyrights: true},
        // Add a map scheme layer
        [new YMapDefaultSchemeLayer({}), new YMapDefaultFeaturesLayer({})]
    );

    const infoElement = document.createElement('span');
    infoElement.classList.add('info');

    const rulerButtonElement = document.createElement('span');
    rulerButtonElement.classList.add('ruler-button');
    rulerButtonElement.textContent = 'ruler';
    const planimeterButtonElement = document.createElement('span');
    planimeterButtonElement.classList.add('planimeter-button');
    planimeterButtonElement.textContent = 'planimeter';

    const controlsRight = new YMapControls({position: 'top right'}, [
        new YMapControlButton({element: rulerButtonElement, onClick: () => ruler.update({type: 'ruler'})}),
        new YMapControlButton({element: planimeterButtonElement, onClick: () => ruler.update({type: 'planimeter'})})
    ]);
    const controlsLeft = new YMapControls({position: 'top left'}, [
        new YMapControlButton({text: 'enable', onClick: () => ruler.update({editable: true})}),
        new YMapControlButton({text: 'disable', onClick: () => ruler.update({editable: false})})
    ]);
    const controlsTop = new YMapControls({position: 'top'}, [new YMapControl({}, infoElement)]);
    map.addChild(controlsLeft).addChild(controlsRight).addChild(controlsTop);

    const previewPoint = document.createElement('div');
    previewPoint.classList.add('preview-point');

    // Ruler point entity
    class RulerPoint extends ymaps3.YMapComplexEntity<RenderPointArgs> {
        private _pointMarker: YMapMarker;
        private _balloonMarker: YMapMarker;
        private _balloonLabelElement: HTMLSpanElement;
        private _balloonElement: HTMLDivElement;
        private _state: RulerPointState;

        private _showBalloon = false;

        constructor(props: RenderPointArgs) {
            super(props);

            this._state = this._props.state;

            const point = document.createElement('div');
            point.classList.add('point');
            point.style.backgroundColor = randomColor();

            this._balloonElement = document.createElement('div');
            this._balloonElement.classList.add('balloon');

            this._balloonLabelElement = document.createElement('span');
            this._balloonLabelElement.textContent = this.__getLabel();
            this._balloonElement.appendChild(this._balloonLabelElement);
            this.__toggleBalloon(this._state.index === this._state.totalCount - 1);

            const deleteButton = document.createElement('button');
            deleteButton.classList.add('button');
            deleteButton.textContent = 'delete';
            deleteButton.addEventListener('click', (event) => {
                event.stopPropagation();
                this._props.onDelete();
            });
            this._balloonElement.appendChild(deleteButton);

            const {coordinates, editable, source} = this._state;

            this._pointMarker = new YMapMarker(
                {
                    coordinates,
                    draggable: editable,
                    source,
                    zIndex: 1,
                    onDragMove: this._props.onDragMove,
                    onFastClick: () => {
                        this._showBalloon = !this._showBalloon;
                        this.__toggleBalloon(this._showBalloon);
                    }
                },
                point
            );
            this._balloonMarker = new YMapMarker({coordinates, source, zIndex: 0}, this._balloonElement);
            this.addChild(this._pointMarker).addChild(this._balloonMarker);
        }

        protected _onUpdate(props: Partial<RenderPointArgs>): void {
            if (props.state !== undefined) {
                this._state = props.state;
                const {coordinates, editable, source} = this._state;

                this._pointMarker.update({coordinates, draggable: editable, source});
                this._balloonMarker.update({coordinates, source});

                this._balloonLabelElement.textContent = this.__getLabel();
                this.__toggleBalloon(
                    !this._showBalloon ? props.state.index === props.state.totalCount - 1 : this._showBalloon
                );
            }
        }

        private __getLabel(): string {
            const {measurements} = this._state;
            return measurements.type === 'ruler'
                ? formatDistance(measurements.distance)
                : formatArea(measurements.area);
        }

        private __toggleBalloon(show: boolean): void {
            this._balloonElement.classList.toggle('hide', !show);
        }
    }

    const ruler = new YMapRuler({
        points: RULER_COORDINATES,
        type: 'ruler',
        editable: true,
        previewPoint,
        geometry: {style: FEATURE_STYLE},
        onUpdate: (state) => {
            infoElement.textContent =
                state.measurements.type === 'ruler'
                    ? `Total distance: ${formatDistance(state.measurements.totalDistance)}`
                    : `Area: ${formatArea(state.measurements.area)}`;
        },
        point: (props) => new RulerPoint(props)
    });
    map.addChild(ruler);
}
