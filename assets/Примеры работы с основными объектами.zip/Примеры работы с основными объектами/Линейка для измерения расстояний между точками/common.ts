import type {DrawingStyle} from '@yandex/ymaps3-types';

export const FEATURE_STYLE: DrawingStyle = {
    simplificationRate: 0,
    fill: '#666',
    fillOpacity: 0.3,
    stroke: [
        {width: 3, opacity: 0.7, color: '#666'},
        {width: 5, opacity: 0.7, color: '#fff'}
    ]
};

export function formatDistance(distance: number): string {
    return distance > 900 ? `${roundDistance(distance / 1000)} km` : `${roundDistance(distance)} m`;
}

export function formatArea(area: number): string {
    return area > 900_000
        ? `${splitNumber(roundDistance(area / 1_000_000))} km²`
        : `${splitNumber(roundDistance(area))} m²`;
}

function roundDistance(distance: number): number {
    if (distance > 100) {
        return Math.round(distance);
    }
    const factor = Math.pow(10, distance > 10 ? 1 : 2);
    return Math.round(distance * factor) / factor;
}

function splitNumber(value: number): string {
    return value.toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
}

// Function for generating a pseudorandom number
const seed = (s: number) => () => {
    s = Math.sin(s) * 10000;
    return s - Math.floor(s);
};
const rnd = seed(10000); // () => Math.random()

export function randomColor() {
    return '#' + (((1 << 24) * rnd()) | 0).toString(16).padStart(6, '0');
}
