import {MINIMAP_PROPS} from '../common';
import {LOCATION} from '../variables';

window.map = null;

main();
async function main() {
    await ymaps3.ready;
    const {YMap, YMapDefaultSchemeLayer, YMapDefaultFeaturesLayer, YMapControls} = ymaps3;

    const {YMapMiniMap} = await ymaps3.import('@yandex/ymaps3-minimap');

    map = new YMap(document.getElementById('app'), {location: LOCATION}, [
        new YMapDefaultSchemeLayer({}),
        new YMapDefaultFeaturesLayer({})
    ]);

    const minimap = new YMapMiniMap({...MINIMAP_PROPS});

    map.addChild(new YMapControls({position: 'right bottom'}).addChild(minimap));
}
