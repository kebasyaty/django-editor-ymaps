# nodymaps-front

## Project setup
```
npm install
# or
yarn install
```

### Compiles and hot-reloads for development
```
npm run serve
# or
yarn serve
```

### Compiles and minifies for production
```
npm run build
# or
yarn build
```

### Lints and fixes files
```
npm run lint
# or
yarn lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
