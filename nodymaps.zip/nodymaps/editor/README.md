# nodymaps

Vue.js - Yandex Maps
git clone git@bitbucket.org:genkosta/nodymaps.git

## ERRORS

Error: ENOSPC: System limit for number of file watchers reached, watch

1. echo fs.inotify.max_user_watches=524288 | sudo tee -a /etc/sysctl.conf && sudo sysctl -p
2. sysctl --system

Тип карты - Map type
Схема - Scheme
Спутник - Satellite
Гибрид - Hybrid
