import {COMMON_LOCATION_PARAMS, InfoMessage, LOCATION} from '../common';

window.map = null;

async function main() {
    // For each object in the JS API, there is a Vue counterpart
    // To use the Vue version of the API, include the module @yandex/ymaps3-vuefy
    const [ymaps3Vue] = await Promise.all([ymaps3.import('@yandex/ymaps3-vuefy'), ymaps3.ready]);
    const vuefy = ymaps3Vue.vuefy.bindTo(Vue);
    const {YMap, YMapDefaultSchemeLayer, YMapDefaultFeaturesLayer, YMapControls} = vuefy.module(ymaps3);

    // Load the control package and extract the geolocation control from it
    const {YMapGeolocationControl} = vuefy.module(await ymaps3.import('@yandex/ymaps3-default-ui-theme'));

    // Using ymaps3-vuefy, we turn a custom InfoMessage and EventListener into a Vue component
    const InfoMessageV = vuefy.entity(InfoMessage, {text: String});

    const app = Vue.createApp({
        components: {
            YMap,
            YMapDefaultSchemeLayer,
            YMapDefaultFeaturesLayer,
            YMapControls,
            YMapGeolocationControl,
            InfoMessageV
        },
        setup() {
            const refMap = (ref) => {
                window.map = ref?.entity;
            };

            return {LOCATION, refMap, COMMON_LOCATION_PARAMS};
        },
        template: `
      <!--Initialize the map and pass initialization parameters-->
      <YMap :location="LOCATION" :showScaleInCopyrights="true" :ref="refMap">
        <!--Add a map scheme layer-->
        <YMapDefaultSchemeLayer/>
        <YMapDefaultFeaturesLayer/>
        <!-- Using YMapControls you can change the position of the control -->
        <YMapControls position="right">
          <!-- Add the geolocation control to the map -->
          <YMapGeolocationControl v-bind="COMMON_LOCATION_PARAMS"/>
        </YMapControls>
        <!-- Using YMapControls you can change the position of the info window -->
        <YMapControls position="top left">
          <!-- Add the geolocation control to the map -->
          <InfoMessageV text="Click on the button on the right side" />
        </YMapControls>
      </YMap>`
    });
    app.mount('#app');
}
main();
