import {HorizontalTriggerPosition, Position, VerticalTriggerPosition} from '@yandex/ymaps3-drawer-control';
import {LOCATION} from '../variables';
import {
    subscribePositionClick,
    subscribeHorizontalTriggerPositionClick,
    subscribeVerticalTriggerPositionClick
} from '../common';

window.map = null;

main();
async function main() {
    const [ymaps3React] = await Promise.all([ymaps3.import('@yandex/ymaps3-reactify'), ymaps3.ready]);
    const reactify = ymaps3React.reactify.bindTo(React, ReactDOM);

    const {YMap, YMapDefaultSchemeLayer, YMapDefaultFeaturesLayer} = reactify.module(ymaps3);

    const {useState, useCallback, useEffect} = React;

    const {YMapDrawerControl} = reactify.module(await ymaps3.import('@yandex/ymaps3-drawer-control'));

    const App = () => {
        const [open, setOpen] = useState(true);
        const [position, setPosition] = useState<Position>('left');
        const [verticalTriggerPosition, setVerticalTriggerPosition] = useState<VerticalTriggerPosition>('center');
        const [horizontalTriggerPosition, setHorizontalTriggerPosition] = useState<HorizontalTriggerPosition>('center');

        useEffect(() => {
            subscribePositionClick((position) => setPosition(position));
            subscribeVerticalTriggerPositionClick((position) => setVerticalTriggerPosition(position));
            subscribeHorizontalTriggerPositionClick((position) => setHorizontalTriggerPosition(position));
        }, []);

        const content = useCallback(
            () => (
                <div className="drawer-content">
                    <h1>Good day, Sir!</h1>
                    <span>I am a sidebar :)</span>
                </div>
            ),
            []
        );

        const onOpenChange = (value: boolean) => {
            setOpen(!value);
        };

        return (
            <YMap location={LOCATION} ref={(x) => (map = x)}>
                <YMapDefaultSchemeLayer />

                <YMapDefaultFeaturesLayer />

                <YMapDrawerControl
                    position={position}
                    verticalTriggerPosition={verticalTriggerPosition}
                    horizontalTriggerPosition={horizontalTriggerPosition}
                    content={content}
                    open={open}
                    onOpenChange={onOpenChange}
                />
            </YMap>
        );
    };

    ReactDOM.render(
        <React.StrictMode>
            <App />
        </React.StrictMode>,
        document.getElementById('app')
    );
}
