import {YMapMiniMapProps} from '@yandex/ymaps3-minimap';
import {YMapControl} from '@yandex/ymaps3-types';
import {MINIMAP_BOUNDS_STYLE} from './variables';

ymaps3.import.registerCdn('https://cdn.jsdelivr.net/npm/{package}', ['@yandex/ymaps3-minimap@0.0.3']);

export const MINIMAP_PROPS: YMapMiniMapProps = {
    size: [260, 170],
    showCollapsedControl: false,
    zoomOffset: 3,
    showBounds: true,
    boundsDrawingStyle: MINIMAP_BOUNDS_STYLE
};
