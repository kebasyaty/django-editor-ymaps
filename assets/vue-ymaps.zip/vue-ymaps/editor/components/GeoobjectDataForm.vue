<!--
--------------------------------------
Component for entering geoobject data.
--------------------------------------
-->
<template>
  <v-conteiner fluid>
    <v-row>
      <v-col cols="12">
        <v-text-field
          flat
          dense
          outlined
          clearable
          hide-details
          full-width
          counter="256"
          prepend-icon="mdi-page-layout-header"
          :label="$t('message.14')"
          name="header"
          v-model="updateHeader"
        ></v-text-field>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="12">
        <v-file-input
          flat
          dense
          counter
          outlined
          show-size
          clearable
          full-width
          hide-details
          prepend-icon="mdi-page-layout-body"
          accept="image/jpeg,image/png"
          :label="$t('message.84')"
          name="body"
          v-model="updateBody"
        ></v-file-input
      ></v-col>
    </v-row>
    <v-row>
      <v-col cols="12">
        <v-textarea
          flat
          dense
          clearable
          hide-details
          outlined
          full-width
          prepend-icon="mdi-page-layout-footer"
          counter="1000"
          name="footer"
          :label="$t('message.149')"
          v-model="updateFooter"
        ></v-textarea>
      </v-col>
    </v-row>
  </v-conteiner>
</template>

<script>
import { mapState, mapMutations } from "vuex";

export default {
  name: "GeoobjectDataForm",
  computed: {
    ...mapState("geoobjectDataForm", ["header", "body", "footer"]),
    updateHeader: {
      get() {
        return this.header;
      },
      set(text) {
        this.setHeader(text);
      },
    },
    updateBody: {
      get() {
        return this.body;
      },
      set(file) {
        this.setHeader(file);
      },
    },
    updateFooter: {
      get() {
        return this.footer;
      },
      set(text) {
        this.setFooter(text);
      },
    },
  },
  methods: {
    ...mapMutations("geoobjectDataForm", ["setHeader", "setBody", "setFooter"]),
  },
};
</script>
