import type {LngLat} from '@yandex/ymaps3-types';
import type {RenderPointArgs, RulerCommonState, RulerType} from '@yandex/ymaps3-types/modules/ruler';
import type TVue from 'vue';
import {FEATURE_STYLE, formatArea, formatDistance, randomColor} from '../common';
import {LOCATION, RULER_COORDINATES} from '../variables';

window.map = null;

async function main() {
    // For each object in the JS API, there is a Vue counterpart
    // To use the Vue version of the API, include the module @yandex/ymaps3-vuefy
    const [ymaps3Vue] = await Promise.all([ymaps3.import('@yandex/ymaps3-vuefy'), ymaps3.ready]);
    const vuefy = ymaps3Vue.vuefy.bindTo(Vue);
    const {
        YMap,
        YMapDefaultSchemeLayer,
        YMapDefaultFeaturesLayer,
        YMapMarker,
        YMapListener,
        YMapControls,
        YMapControl,
        YMapControlButton
    } = vuefy.module(ymaps3);
    const {YMapRuler} = vuefy.module(await ymaps3.import('@yandex/ymaps3-ruler'));

    const RulerPoint = Vue.defineComponent({
        name: 'RulerPoint',
        props: {
            state: Object as TVue.PropType<RenderPointArgs['state']>,
            onDragMove: Function as TVue.PropType<RenderPointArgs['onDragMove']>,
            onDelete: Function as TVue.PropType<RenderPointArgs['onDelete']>
        },
        components: {YMapMarker},
        setup(props) {
            const showBalloon = Vue.ref(false);
            const label = Vue.computed(() => {
                return props.state.measurements.type === 'planimeter'
                    ? formatArea(props.state.measurements.area)
                    : formatDistance(props.state.measurements.distance);
            });

            const showLastBalloon = Vue.computed(() => {
                return props.state.index === props.state.totalCount - 1;
            });

            const onClick = () => {
                showBalloon.value = !showBalloon.value;
            };

            const onDeleteHandler = (event) => {
                event.stopPropagation();
                props.onDelete();
            };

            const backgroundColor = randomColor();

            return {label, showBalloon, showLastBalloon, backgroundColor, onClick, onDeleteHandler};
        },
        template: `
            <template>
                <YMapMarker
                    :key="state.index"
                    :coordinates="state.coordinates"
                    :zIndex="21"
                    :draggable="state.editable"
                    :source="state.source"
                    :onDragMove="onDragMove"
                    :onFastClick="onClick">
                    <div class="point" :style="{backgroundColor}"></div>
                </YMapMarker>
                <YMapMarker v-if="showBalloon || showLastBalloon" :coordinates="state.coordinates" :source="state.source" :zIndex="20">
                    <div class="balloon">
                        <span>{{ label }}</span>
                        <button @click="onDeleteHandler" class="button">delete</button>
                    </div>
                </YMapMarker>
            </template>`
    });

    const app = Vue.createApp({
        components: {
            YMap,
            YMapDefaultSchemeLayer,
            YMapDefaultFeaturesLayer,
            YMapMarker,
            YMapListener,
            YMapControls,
            YMapControl,
            YMapControlButton,
            YMapRuler,
            RulerPoint
        },
        setup() {
            const refMap = (ref) => {
                window.map = ref?.entity;
            };
            const type = Vue.ref<RulerType>('ruler');
            const editable = Vue.ref(true);
            const coordinates = Vue.ref<LngLat[]>(RULER_COORDINATES);
            const commonInfo = Vue.ref('');

            const setRulerType = () => {
                type.value = 'ruler';
            };
            const setPlanimeterType = () => {
                type.value = 'planimeter';
            };
            const onUpdate = ({measurements}: RulerCommonState) => {
                commonInfo.value =
                    measurements.type === 'ruler'
                        ? `Total distance: ${formatDistance(measurements.totalDistance)}`
                        : `Area: ${formatArea(measurements.area)}`;
            };

            return {
                LOCATION,
                FEATURE_STYLE,
                refMap,
                type,
                coordinates,
                editable,
                commonInfo,
                onUpdate,
                setRulerType,
                setPlanimeterType,
                formatDistance,
                formatArea
            };
        },
        template: `
            <YMap :location="LOCATION" :showScaleInCopyrights="true" :ref="refMap">
                <YMapDefaultSchemeLayer />
                <YMapDefaultFeaturesLayer />

                <YMapControls position="top right">
                    <YMapControlButton :onClick="setRulerType">
                        <span class="ruler-button">ruler</span>
                    </YMapControlButton>
                    <YMapControlButton :onClick="setPlanimeterType">
                        <span class="planimeter-button">planimeter</span>
                    </YMapControlButton>
                </YMapControls>

                <YMapControls position="top left">
                    <YMapControlButton text="enable" :onClick="() => editable = true" />
                    <YMapControlButton text="disable" :onClick="() => editable = false" />
                </YMapControls>

                <YMapControls position="top">
                    <YMapControl>
                        <span className="info">{{commonInfo}}</span>
                    </YMapControl>
                </YMapControls>

                <YMapRuler
                    :points="coordinates"
                    :editable="editable"
                    :geometry="{style: FEATURE_STYLE}"
                    :type="type"
                    :onUpdate="onUpdate">
                    <template #point="params">
                        <RulerPoint v-bind="params" />
                    </template>
                    <template #previewPoint>
                        <div class="preview-point"></div>
                    </template>
                </YMapRuler>
            </YMap>`
    });
    app.mount('#app');
}
main();
