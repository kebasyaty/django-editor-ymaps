import type {YMapLocationRequest} from '@yandex/ymaps3-types';

export const LOCATION: YMapLocationRequest = {
    center: [104.284, 52.289], // starting position [lng, lat]
    zoom: 13.5 // starting zoom
};
