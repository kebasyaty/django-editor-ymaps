/*
 * Module for the Modals.vue component.
 */

import i18n from "@/locales/i18n.js";

export default {
  namespaced: true,
  state: {
    // Geoobject
    // -------------------------------------------------------------------------
    geoobjectDialog: false, // Open/Close
    titleGeoobjectDialog: "Title",
    geoobjectEditBtn: true,
    geoobjectSaveBtn: true,
    geoobjectCancelBtn: true,
    geoobjectDeleteBtn: true,
    geoobjectCurrentActionBtnEdit: null,
    geoobjectCurrentActionBtnSave: null,
    geoobjectCurrentActionBtnCancel: null,
    geoobjectCurrentActionBtnDelete: null,
    componentGeoobjectHeatPoint: false, // Show/Hide
    componentGeoobjectPlacemark: false, // Show/Hide
    componentGeoobjectPolyline: false, // Show/Hide
    componentGeoobjectPolygon: false, // Show/Hide
    // Controls
    // -------------------------------------------------------------------------
    controlsDialog: false, // Open/Close
    titleControlsDialog: "Title",
    textControlsDialog: "Text | Html",
    controlsCancelBtn: true,
    controlsSaveBtn: true,
    componentControlsText: false, // Show/Hide
    componentControlsPalette: false, // Show/Hide
    componentControlsMenu: false, // Show/Hide
    componentControlsIconCollection: false, // Show/Hide
    componentControlsGeoobjectDataForm: false, // Show/Hide
    componentControlsCategories: false, // Show/Hide
    componentControlsImageCrop: false, // Show/Hide
    currentColorPalette: "#F44336FF",
    controlsCurrentActionBtnCancel: null,
    controlsCurrentActionBtnSave: null,
    // Message
    // -------------------------------------------------------------------------
    messageDialog: false, // Open/Close
    statusMessageDialog: "success", // accent ; error ; info ; success ; warning
    titleMessageDialog: "Text | Html",
    textMessageDialog: "Text | Html",
    messageCancelBtn: true,
    messageOkBtn: true,
    messageCurrentActionBtnCancel: null,
    messageCurrentActionBtnOk: null,
    // Simple messages
    // -------------------------------------------------------------------------
    alertSnackbar: false, // Open/Close
    textSnackbar: "Text | Html",
    // Global progress bar
    // -------------------------------------------------------------------------
    globalProgressBar: false, // Open/Close
  },
  getters: {},
  mutations: {
    // Geoobject
    // -------------------------------------------------------------------------
    geoobjectDialogShow(state, payload) {
      // Open
      state.titleGeoobjectDialog = payload.title;
      state.geoobjectEditBtn = payload.editBtn; // Show/Hide
      state.geoobjectSaveBtn = payload.saveBtn; // Show/Hide
      state.geoobjectCancelBtn = payload.cancelBtn; // Show/Hide
      state.geoobjectDeleteBtn = payload.deleteBtn; // Show/Hide
      state.geoobjectCurrentActionBtnEdit = payload.actionBtnEdit;
      state.geoobjectCurrentActionBtnSave = payload.actionBtnSave;
      state.geoobjectCurrentActionBtnCancel = payload.actionBtnCancel;
      state.geoobjectCurrentActionBtnDelete = payload.actionBtnDelete;
      state.geoobjectDialog = true;
      state.componentGeoobjectHeatPoint = !!payload.componentHeatPoint; // Show/Hide
      state.componentGeoobjectPlacemark = !!payload.componentPlacemark; // Show/Hide
      state.componentGeoobjectPolyline = !!payload.componentPolyline; // Show/Hide
      state.componentGeoobjectPolygon = !!payload.componentPolygon; // Show/Hide
    },
    geoobjectDialogClose(state) {
      // Close
      state.geoobjectDialog = false;
    },
    // Controls
    // -------------------------------------------------------------------------
    controlsDialogShow(state, payload) {
      // Open
      state.titleControlsDialog = payload.title;
      state.textControlsDialog = payload.text;
      state.controlsCancelBtn = payload.cancelBtn; // Show/Hide
      state.controlsSaveBtn = payload.saveBtn; // Show/Hide
      state.componentControlsText = !!payload.componentText;
      state.componentControlsPalette = !!payload.componentPalette;
      state.componentControlsMenu = !!payload.componentMenu;
      state.componentControlsIconCollection = !!payload.componentIcons;
      state.componentControlsGeoobjectDataForm =
        !!payload.componentGeoobjectDataForm;
      state.componentControlsCategories = !!payload.componentCategories;
      state.componentControlsImageCrop = !!payload.componentImageCrop;
      if (payload.componentPalette) {
        state.currentColorPalette = payload.palette.currentColor;
      }
      state.controlsCurrentActionBtnSave = payload.actionBtnSave;
      state.controlsCurrentActionBtnCancel = payload.actionBtnCancel;
      state.controlsDialog = true;
    },
    controlsDialogClose(state) {
      // Close
      state.controlsDialog = false;
    },
    refreshCurrentColorPalette(state, color) {
      state.currentColorPalette = color;
    },
    destroyComponentControlsImageCrop(state) {
      state.componentControlsImageCrop = false;
    },
    // Message
    // -------------------------------------------------------------------------
    messageDialogShow(state, payload) {
      // Open
      state.statusMessageDialog = payload.status;
      state.titleMessageDialog = payload.title;
      state.textMessageDialog = payload.text;
      state.messageCancelBtn = payload.cancelBtn; // Show/Hide
      state.messageOkBtn = payload.okBtn; // Show/Hide
      state.messageCurrentActionBtnCancel = payload.actionBtnCancel;
      state.messageCurrentActionBtnOk = payload.actionBtnOk;
      state.messageDialog = true;
    },
    messageDialogClose(state) {
      // Close
      state.messageDialog = false;
    },
    // Simple messages
    // -------------------------------------------------------------------------
    alertSnackbarShow(state, text) {
      // Open
      state.textSnackbar = text;
      state.alertSnackbar = true;
    },
    alertSnackbarClose(state) {
      // Close
      state.alertSnackbar = false;
    },
    // Global progress bar
    // -------------------------------------------------------------------------
    globalProgressBarShow(state, flag) {
      // Open/Close
      state.globalProgressBar = flag;
    },
  },
  actions: {
    // Ajax - Error processing.
    ajaxErrorProcessing({ commit }, payload) {
      const jqxhr = payload.jqxhr;
      const textStatus = payload.textStatus;
      const error = payload.error;
      const err = `${textStatus} , ${error}`;
      const hint = payload.hint;
      let errDetail = "";

      if (
        jqxhr.responseJSON !== undefined &&
        jqxhr.responseJSON.detail !== undefined
      ) {
        errDetail = jqxhr.responseJSON.detail;
        window.console.log(`Request Failed: ${err} - ${errDetail}`);
        commit("messageDialogShow", {
          status: "error",
          title: i18n.t("message.86"),
          text: `${errDetail} <br>Hint: ${hint}`,
          cancelBtn: true,
          okBtn: false,
          actionBtnCancel: () => commit("messageDialogClose"),
          actionBtnOk: null,
        });
      } else {
        const msg = `ERROR<br>Request Failed -> ${err}`;
        window.console.log(msg);
        commit("alertSnackbarShow", `${msg} <br>Hint -> ${hint}`);
      }
    },
  },
};
