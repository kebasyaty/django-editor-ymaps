import {LOCATION} from '../variables';
import {
    subscribePositionClick,
    subscribeVerticalTriggerPositionClick,
    subscribeHorizontalTriggerPositionClick
} from '../common';
window.map = null;

main();
async function main() {
    await ymaps3.ready;
    const {YMap, YMapDefaultSchemeLayer, YMapDefaultFeaturesLayer} = ymaps3;

    const {YMapDrawerControl} = await ymaps3.import('@yandex/ymaps3-drawer-control');

    map = new YMap(document.getElementById('app'), {location: LOCATION}, [
        new YMapDefaultSchemeLayer({}),
        new YMapDefaultFeaturesLayer({})
    ]);

    let open = true;

    const drawerControl = new YMapDrawerControl({
        position: 'left',
        open,
        onOpenChange: (value: boolean) => {
            open = !value;
            drawerControl.update({open});
        },
        content: () => {
            const container = document.createElement('div');
            container.classList.add('drawer-content');

            const title = document.createElement('h1');
            title.textContent = 'Good day, Sir!';
            container.appendChild(title);

            const text = document.createElement('span');
            text.textContent = 'I am a sidebar :)';
            container.appendChild(text);
            return container;
        }
    });

    subscribePositionClick((position) => drawerControl.update({position}));
    subscribeVerticalTriggerPositionClick((verticalTriggerPosition) => drawerControl.update({verticalTriggerPosition}));
    subscribeHorizontalTriggerPositionClick((horizontalTriggerPosition) =>
        drawerControl.update({horizontalTriggerPosition})
    );

    map.addChild(drawerControl);
}
