import {Position, VerticalTriggerPosition, HorizontalTriggerPosition} from '@yandex/ymaps3-drawer-control';

ymaps3.import.registerCdn('https://cdn.jsdelivr.net/npm/{package}', '@yandex/ymaps3-drawer-control@0.0');

// code for position control
type PositionCallback = (position: Position) => void;
type VerticalTriggerPositionCallback = (position: VerticalTriggerPosition) => void;
type HorizontalTriggerPositionCallback = (position: HorizontalTriggerPosition) => void;

const positionButtons: Record<Position, HTMLElement> = {
    top: document.getElementById('position-top'),
    bottom: document.getElementById('position-bottom'),
    left: document.getElementById('position-left'),
    right: document.getElementById('position-right')
};

const verticalContainer = document.getElementById('vertical-container');
const verticalTriggerPositionButtons: Record<VerticalTriggerPosition, HTMLElement> = {
    top: document.getElementById('vp-top'),
    center: document.getElementById('vp-center'),
    bottom: document.getElementById('vp-bottom')
};

const horizontalContainer = document.getElementById('horizontal-container');
const horizontalTriggerPositionButtons: Record<HorizontalTriggerPosition, HTMLElement> = {
    left: document.getElementById('hp-left'),
    center: document.getElementById('hp-center'),
    right: document.getElementById('hp-right')
};

const positionObservers: Array<PositionCallback> = [];
const verticalTriggerPositionObservers: Array<VerticalTriggerPositionCallback> = [];
const horizontalTriggerPositionObservers: Array<HorizontalTriggerPositionCallback> = [];

Object.keys(positionButtons).forEach((position: Position) => {
    positionButtons[position].addEventListener('click', () => {
        positionObservers.forEach((cb) => cb(position));
        Object.keys(positionButtons).forEach((key: Position) =>
            positionButtons[key].classList.toggle('active', key === position)
        );

        verticalContainer.classList.toggle('left', position === 'left');
        verticalContainer.classList.toggle('right', position === 'right');
        horizontalContainer.classList.toggle('top', position === 'top');
        horizontalContainer.classList.toggle('bottom', position === 'bottom');
    });
});

Object.keys(verticalTriggerPositionButtons).forEach((position: VerticalTriggerPosition) => {
    verticalTriggerPositionButtons[position].addEventListener('click', () => {
        verticalTriggerPositionObservers.forEach((cb) => cb(position));
        Object.keys(verticalTriggerPositionButtons).forEach((key: VerticalTriggerPosition) =>
            verticalTriggerPositionButtons[key].classList.toggle('active', key === position)
        );
    });
});

Object.keys(horizontalTriggerPositionButtons).forEach((position: HorizontalTriggerPosition) => {
    horizontalTriggerPositionButtons[position].addEventListener('click', () => {
        horizontalTriggerPositionObservers.forEach((cb) => cb(position));
        Object.keys(horizontalTriggerPositionButtons).forEach((key: HorizontalTriggerPosition) =>
            horizontalTriggerPositionButtons[key].classList.toggle('active', key === position)
        );
    });
});

export const subscribePositionClick = (cb: PositionCallback) => {
    positionObservers.push(cb);
};
export const subscribeVerticalTriggerPositionClick = (cb: VerticalTriggerPositionCallback) => {
    verticalTriggerPositionObservers.push(cb);
};
export const subscribeHorizontalTriggerPositionClick = (cb: HorizontalTriggerPositionCallback) => {
    horizontalTriggerPositionObservers.push(cb);
};
