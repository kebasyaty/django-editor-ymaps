import type {LngLat} from '@yandex/ymaps3-types';
import {LOCATION, NAMES, BOUNDS, getImageSrc} from '../variables';
import {COMMON_LOCATION_PARAMS, type ExpandedFeature, getBounds, getRandomPoints, MARGIN} from '../common';

window.map = null;

main();
async function main() {
    // Waiting for all api elements to be loaded
    await ymaps3.ready;
    const {YMap, YMapDefaultSchemeLayer, YMapDefaultFeaturesLayer, YMapMarker} = ymaps3;
    const {YMapClusterer, clusterByGrid} = await ymaps3.import('@yandex/ymaps3-clusterer');

    map = new YMap(document.getElementById('app'), {location: LOCATION, showScaleInCopyrights: true, margin: MARGIN}, [
        // Add a map scheme layer
        new YMapDefaultSchemeLayer({}),
        // Add a layer of geo objects to display the markers
        new YMapDefaultFeaturesLayer({})
    ]);

    /* We declare the function for rendering ordinary markers, we will submit it to the clusterer settings.
  Note that the function must return any Entity element. In the example, this is YMapDefaultMarker. */
    const marker = (feature: ExpandedFeature) => {
        const markerContainerElement = document.createElement('div');
        markerContainerElement.classList.add('marker-container');

        const markerText = document.createElement('div');
        markerText.id = feature.id;
        markerText.classList.add('marker-text', 'hidden');
        markerText.innerText = NAMES[feature.id];

        markerContainerElement.onmouseover = () => {
            markerText.classList.replace('hidden', 'visible');
        };

        markerContainerElement.onmouseout = () => {
            markerText.classList.replace('visible', 'hidden');
        };

        const markerElement = document.createElement('div');
        markerElement.classList.add('marker');

        const markerImage = document.createElement('img');
        markerImage.src = getImageSrc(feature.id);
        markerImage.classList.add('image');

        markerElement.appendChild(markerImage);

        markerContainerElement.appendChild(markerText);
        markerContainerElement.appendChild(markerElement);

        return new YMapMarker(
            {
                coordinates: feature.geometry.coordinates
            },
            markerContainerElement
        );
    };

    // As for ordinary markers, we declare a cluster rendering function that also returns an Entity element.
    const cluster = (coordinates: LngLat, features: ExpandedFeature[]) =>
        new YMapMarker(
            {
                coordinates,
                onClick() {
                    const bounds = getBounds(features.map((feature: ExpandedFeature) => feature.geometry.coordinates));
                    map.update({location: {bounds, ...COMMON_LOCATION_PARAMS}});
                }
            },
            circle(features.length).cloneNode(true) as HTMLElement
        );

    function circle(count: number) {
        const circle = document.createElement('div');
        circle.classList.add('circle');
        circle.innerHTML = `
                  <div class="circle-content">
                      <span class="circle-text">${count}</span>
                  </div>
              `;
        return circle;
    }

    /* We create a clusterer object and add it to the map object.
  As parameters, we pass the clustering method, an array of features, the functions for rendering markers and clusters.
  For the clustering method, we will pass the size of the grid division in pixels. */
    const clusterer = new YMapClusterer({
        method: clusterByGrid({gridSize: 64}),
        features: getRandomPoints(BOUNDS),
        marker,
        cluster
    });
    map.addChild(clusterer);
}
