import {LOCATION, InfoMessage, COMMON_LOCATION_PARAMS} from '../common';

window.map = null;

main();
async function main() {
    // Waiting for all api elements to be loaded
    await ymaps3.ready;
    const {YMap, YMapDefaultSchemeLayer, YMapDefaultFeaturesLayer, YMapControls} = ymaps3;

    // Load the control package and extract the geolocation control from it
    const {YMapGeolocationControl} = await ymaps3.import('@yandex/ymaps3-default-ui-theme');

    // Initialize the map
    map = new YMap(
        // Pass the link to the HTMLElement of the container
        document.getElementById('app'),
        // Pass the map initialization parameters
        {location: LOCATION, showScaleInCopyrights: true},
        [
            // Add a map scheme layer
            new YMapDefaultSchemeLayer({}),
            // Add a layer of geo objects to display the geolocation marker
            new YMapDefaultFeaturesLayer({})
        ]
    );

    map.addChild(
        // Using YMapControls you can change the position of the control
        new YMapControls({position: 'right'})
            // Add the geolocation control to the map
            .addChild(new YMapGeolocationControl(COMMON_LOCATION_PARAMS))
    );
    map.addChild(
        // Using YMapControls you can change the position of the control
        new YMapControls({position: 'top left'})
            // Add the geolocation control to the map
            .addChild(
                new InfoMessage({
                    text: 'Click on the button on the right side'
                })
            )
    );
}
