<!--
----------------------------
Component for popup dialogs.
----------------------------
-->
<template>
  <!--eslint-disable vue/no-v-text-v-html-on-component-->
  <div>
    <!-- Geoobject -->
    <v-overlay z-index="8" :value="geoobjectDialog">
      <v-card :light="!$vuetify.theme.dark" width="300px" max-width="300px">
        <v-card-title
          class="subtitle-1 justify-center py-0"
          :style="`background-color:${colorControlsTheme};color:${colorButtonsTextTheme};`"
          v-html="titleGeoobjectDialog"
        ></v-card-title>
        <v-divider></v-divider>
        <v-card-text class="pt-5">
          <!-- Context Menu - Create and editable a Heat Point. -->
          <ContextmenuHeatPoint v-if="componentGeoobjectHeatPoint" />
          <!-- Context Menu - Create and editable a Placemark. -->
          <ContextmenuPlacemark v-if="componentGeoobjectPlacemark" />
          <!-- Context Menu - Create and editable a Route. -->
          <ContextmenuRoute v-if="componentGeoobjectPolyline" />
          <!-- Context Menu - Create and editable a Territory. -->
          <ContextmenuTerritory v-if="componentGeoobjectPolygon" />
        </v-card-text>
        <!--<v-divider></v-divider>-->
        <v-card-actions class="pt-0 pb-2">
          <v-spacer></v-spacer>
          <v-btn
            fab
            x-small
            depressed
            :color="colorControlsTheme"
            @click="geoobjectCurrentActionBtnEdit()"
            v-show="geoobjectEditBtn"
          >
            <v-icon
              :color="colorButtonsTextTheme"
              v-text="getIconBtnEdit()"
            ></v-icon>
          </v-btn>
          <v-btn
            fab
            x-small
            depressed
            :color="colorControlsTheme"
            @click="geoobjectCurrentActionBtnSave()"
            v-show="geoobjectSaveBtn"
          >
            <v-icon :color="colorButtonsTextTheme">mdi-content-save</v-icon>
          </v-btn>
          <v-btn
            fab
            x-small
            depressed
            :color="colorControlsTheme"
            @click="messageDelete()"
            v-show="geoobjectDeleteBtn"
          >
            <v-icon :color="colorButtonsTextTheme">mdi-trash-can</v-icon>
          </v-btn>
          <v-btn
            fab
            x-small
            depressed
            :color="colorControlsTheme"
            @click="geoobjectCurrentActionBtnCancel()"
            v-show="geoobjectCancelBtn"
          >
            <v-icon :color="colorButtonsTextTheme">mdi-close-thick</v-icon>
          </v-btn>
          <v-spacer></v-spacer>
        </v-card-actions>
      </v-card>
    </v-overlay>

    <!-- Controls -->
    <v-overlay z-index="9" :value="controlsDialog">
      <v-card :light="!$vuetify.theme.dark" max-height="80%">
        <v-card-title
          class="subtitle-1 justify-center py-0"
          :style="controlsTitleColor(componentControlsMenu)"
          v-html="titleControlsDialog"
        ></v-card-title>
        <v-divider></v-divider>
        <v-card-text
          v-if="componentControlsText"
          v-html="textControlsDialog"
          class="pt-5"
        ></v-card-text>
        <v-card-text v-if="componentControlsPalette" class="pt-5">
          <v-color-picker
            mode="hexa"
            v-model="updateCurrentColorPalette"
            hide-mode-switch
            show-swatches
          ></v-color-picker>
        </v-card-text>
        <!-- Menu - Select a type and create a geoobject. -->
        <v-card-text v-if="componentControlsMenu" class="pt-5">
          <DialogCreate />
        </v-card-text>
        <!-- Icon list - Select the icon for the marker. -->
        <v-card-text v-show="componentControlsIconCollection" class="pt-5">
          <IconCollection />
        </v-card-text>
        <!-- Form for entering geoobject data. -->
        <v-card-text
          v-if="componentControlsGeoobjectDataForm"
          class="px-3 py-0"
        >
          <GeoobjectDataForm />
        </v-card-text>
        <!-- Select a Categories. -->
        <v-card-text v-if="componentControlsCategories" class="px-3 py-0">
          <SelectCategories />
        </v-card-text>
        <!-- Image cropping. -->
        <v-card-text
          v-if="componentControlsImageCrop"
          class="px-3 py-0"
          style="min-width: 324px"
        >
          <ImageCrop />
        </v-card-text>
        <v-divider v-if="componentControlsGeoobjectDataForm"></v-divider>
        <v-card-actions
          :class="
            componentControlsGeoobjectDataForm
              ? 'py-1'
              : componentControlsCategories
                ? 'py-2'
                : 'pt-0 pb-2'
          "
        >
          <v-spacer></v-spacer>
          <v-btn
            fab
            x-small
            depressed
            :color="colorControlsTheme"
            @click="controlsCurrentActionBtnSave()"
            v-show="controlsSaveBtn"
          >
            <v-icon :color="colorButtonsTextTheme">mdi-thumb-up</v-icon>
          </v-btn>
          <v-btn
            fab
            x-small
            depressed
            :color="colorControlsTheme"
            @click="controlsCurrentActionBtnCancel()"
            v-show="controlsCancelBtn"
          >
            <v-icon :color="colorButtonsTextTheme">mdi-close-thick</v-icon>
          </v-btn>
          <v-spacer></v-spacer>
        </v-card-actions>
      </v-card>
    </v-overlay>

    <!-- Message -->
    <v-dialog v-model="messageDialog" persistent max-width="500">
      <v-card :light="!$vuetify.theme.dark">
        <v-card-title
          class="subtitle-1 py-0"
          :class="
            statusMessageDialog !== 'delete' ? statusMessageDialog : 'error'
          "
          v-text="titleMessageDialog"
          :style="`color:white;`"
        ></v-card-title>
        <v-card-text class="pt-5 font-weight-bold">
          <table>
            <tr>
              <td width="56" style="position: relative; min-height: 42px">
                <div style="position: absolute; top: 50%; margin-top: -21px">
                  <v-icon
                    v-if="statusMessageDialog == 'success'"
                    color="success"
                    x-large
                    >mdi-check-circle-outline</v-icon
                  >
                  <v-icon
                    v-else-if="statusMessageDialog == 'accent'"
                    color="accent"
                    x-large
                    >mdi-alert-outline</v-icon
                  >
                  <v-icon
                    v-else-if="statusMessageDialog == 'error'"
                    color="error"
                    x-large
                    >mdi-lightbulb-alert</v-icon
                  >
                  <v-icon
                    v-else-if="statusMessageDialog == 'info'"
                    color="info"
                    x-large
                    >mdi-information-variant-circle-outline</v-icon
                  >
                  <v-icon
                    v-else-if="statusMessageDialog == 'warning'"
                    color="warning"
                    x-large
                    >mdi-alert-outline</v-icon
                  >
                  <v-icon
                    v-else-if="statusMessageDialog == 'delete'"
                    color="error"
                    x-large
                    >mdi-trash-can-outline</v-icon
                  >
                </div>
              </td>
              <td v-html="textMessageDialog"></td>
            </tr>
          </table>
        </v-card-text>
        <!--<v-divider></v-divider>-->
        <v-card-actions class="pt-0 pb-2">
          <v-spacer></v-spacer>
          <v-btn
            fab
            x-small
            depressed
            :color="colorControlsTheme"
            @click="messageCurrentActionBtnOk()"
            v-show="messageOkBtn"
          >
            <v-icon :color="colorButtonsTextTheme">mdi-thumb-up</v-icon>
          </v-btn>
          <v-btn
            fab
            x-small
            depressed
            :color="colorControlsTheme"
            @click="messageCurrentActionBtnCancel()"
            v-show="messageCancelBtn"
          >
            <v-icon :color="colorButtonsTextTheme">mdi-close-thick</v-icon>
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <!-- Simple messages -->
    <v-snackbar v-model="alertSnackbar" top multi-line vertical :timeout="0">
      <span class="font-weight-bold" v-html="textSnackbar"></span>
      <v-btn
        fab
        x-small
        depressed
        :color="colorControlsTheme"
        @click="alertSnackbarClose()"
      >
        <v-icon :color="colorButtonsTextTheme">mdi-close</v-icon>
      </v-btn>
    </v-snackbar>

    <!-- Global progress bar -->
    <v-overlay z-index="10000" :value="globalProgressBar">
      <v-progress-circular indeterminate size="64"></v-progress-circular>
    </v-overlay>
  </div>
</template>

<script>
import { mapState, mapMutations } from "vuex";
import DialogCreate from "@/components/DialogCreate.vue";
import IconCollection from "@/components/IconCollection.vue";
import GeoobjectDataForm from "@/components/GeoobjectDataForm.vue";
import SelectCategories from "@/components/SelectCategories.vue";
import ImageCrop from "@/components/ImageCrop.vue";
import ContextmenuHeatPoint from "@/components/ContextmenuHeatPoint.vue";
import ContextmenuPlacemark from "@/components/ContextmenuPlacemark.vue";
import ContextmenuRoute from "@/components/ContextmenuRoute.vue";
import ContextmenuTerritory from "@/components/ContextmenuTerritory.vue";

export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Modals",
  components: {
    DialogCreate,
    IconCollection,
    GeoobjectDataForm,
    SelectCategories,
    ImageCrop,
    ContextmenuHeatPoint,
    ContextmenuPlacemark,
    ContextmenuRoute,
    ContextmenuTerritory,
  },
  computed: {
    ...mapState("modals", [
      // Geoobject
      // -----------------------------------------------------------------------
      "geoobjectDialog", // Open/Close
      "titleGeoobjectDialog",
      "geoobjectEditBtn",
      "geoobjectSaveBtn",
      "geoobjectCancelBtn",
      "geoobjectDeleteBtn",
      "geoobjectCurrentActionBtnEdit",
      "geoobjectCurrentActionBtnSave",
      "geoobjectCurrentActionBtnCancel",
      "geoobjectCurrentActionBtnDelete",
      "componentGeoobjectHeatPoint", // Show/Hide
      "componentGeoobjectPlacemark", // Show/Hide
      "componentGeoobjectPolyline", // Show/Hide
      "componentGeoobjectPolygon", // Show/Hide
      // Controls
      // -----------------------------------------------------------------------
      "controlsDialog", // Open/Close
      "titleControlsDialog",
      "textControlsDialog",
      "controlsCancelBtn",
      "controlsSaveBtn",
      "componentControlsText", // Show/Hide
      "componentControlsPalette", // Show/Hide
      "componentControlsMenu", // Show/Hide
      "componentControlsIconCollection", // Show/Hide
      "componentControlsGeoobjectDataForm", // Show/Hide
      "componentControlsCategories", // Show/Hide
      "componentControlsImageCrop", // Show/Hide
      "currentColorPalette",
      "controlsCurrentActionBtnCancel",
      "controlsCurrentActionBtnSave",
      // Message
      // -----------------------------------------------------------------------
      "messageDialog", // Open/Close
      "titleMessageDialog",
      "statusMessageDialog",
      "textMessageDialog",
      "messageCancelBtn",
      "messageOkBtn",
      "messageCurrentActionBtnCancel",
      "messageCurrentActionBtnOk",
      // Simple messages
      // -----------------------------------------------------------------------
      "alertSnackbar", // Open/Close
      "textSnackbar",
      // Global progress bar
      // -----------------------------------------------------------------------
      "globalProgressBar",
    ]),
    ...mapState("generalSettings", [
      "colorControlsTheme",
      "colorButtonsTextTheme",
    ]),
    ...mapState("ymap", ["editableGeoobject"]),
    // Refresh current palette color.
    updateCurrentColorPalette: {
      get() {
        return this.currentColorPalette;
      },
      set(newColor) {
        this.refreshCurrentColorPalette(newColor);
      },
    },
  },
  methods: {
    ...mapMutations("modals", [
      // Geoobject
      "geoobjectDialogClose",
      // Controls
      "controlsDialogClose",
      "refreshCurrentColorPalette",
      // Message
      "messageDialogShow",
      "messageDialogClose",
      // Simple messages.
      "alertSnackbarClose",
    ]),
    controlsTitleColor(flag) {
      return flag
        ? `background-color:${this.colorControlsTheme};color:${this.colorButtonsTextTheme};`
        : "";
    },
    // Get Icon for button "Edit" - Popup "geoobjectDialog".
    getIconBtnEdit() {
      let iconName;
      if (this.componentGeoobjectPlacemark) {
        iconName = "mdi-map-marker-distance";
      } else if (this.editableGeoobject !== null) {
        const coordinates = this.editableGeoobject.geometry.getCoordinates();
        try {
          if (coordinates.length > 1 || coordinates[0].length > 1) {
            iconName = "mdi-square-edit-outline";
          } else {
            iconName = "mdi-plus-thick";
          }
        } catch (err) {
          iconName = "mdi-plus-thick";
        }
      }
      return iconName;
    },
    // Warning about deleting a geo object.
    messageDelete() {
      this.messageDialogShow({
        status: "delete",
        title: this.$t("message.85"),
        text: this.$t("message.44"),
        cancelBtn: true,
        okBtn: true,
        actionBtnCancel: this.messageDialogClose,
        actionBtnOk: this.geoobjectCurrentActionBtnDelete,
      });
    },
  },
};
</script>
