import type {LngLatBounds, YMapLocationRequest} from '@yandex/ymaps3-types';

export const LOCATION: YMapLocationRequest = {
    center: [82.8665, 55.0964], // starting position [lng, lat]
    zoom: 13 // starting zoom
};

/* Rectangle bounded by bottom-left and top-right coordinates
Inside it, we generate the first bundle of clusterer points */
export const BOUNDS: LngLatBounds = [
    [82.8291, 55.054],
    [82.8957, 55.1638]
];
export const NAMES = [
    'Пушок',
    'Филипп',
    'Бабочка',
    'Себастиан',
    'Кирилл',
    'Ной',
    'Роберто',
    'Лили',
    'Курт',
    'Лиса',
    'Марго',
    'Мими',
    'Мини',
    'Полина',
    'Бенджамин',
    'Маша',
    'Серёжа',
    'Арнольд',
    'Саша',
    'Алина',
    'Роза',
    'Варя',
    'Натали',
    'Лизи',
    'Толя',
    'Катя',
    'Алекс',
    'Билли',
    'Фродо',
    'Михаель',
    'Печенька',
    'Легалас',
    'Бусинка',
    'Гимли',
    'Моника',
    'Нора',
    'Ветерок',
    'Луиза',
    'Ксюша',
    'Тина'
];

export const getImageSrc = (id: string) => `../squirrels/image${id}.png`;

