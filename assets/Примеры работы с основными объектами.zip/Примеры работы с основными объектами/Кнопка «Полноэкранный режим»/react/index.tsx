import type {LngLat} from '@yandex/ymaps3-types';
import {LOCATION, InfoMessage, COMMON_LOCATION_PARAMS} from '../common';

window.map = null;

main();

async function main() {
    // For each object in the JS API, there is a React counterpart
    // To use the React version of the API, include the module @yandex/ymaps3-reactify
    const [ymaps3React] = await Promise.all([ymaps3.import('@yandex/ymaps3-reactify'), ymaps3.ready]);
    const reactify = ymaps3React.reactify.bindTo(React, ReactDOM);
    const {YMap, YMapDefaultSchemeLayer, YMapDefaultFeaturesLayer, YMapControls, YMapListener} =
        reactify.module(ymaps3);

    // Load the control package and extract the geolocation control from it
    const {YMapGeolocationControl} = reactify.module(await ymaps3.import('@yandex/ymaps3-default-ui-theme'));

    // Using ymaps3-rectify, we turn a custom InfoMessage and EventListener into a React component
    const InfoMessageR = reactify.entity(InfoMessage);

    function App() {
        return (
            // Initialize the map and pass initialization parameters
            <YMap location={LOCATION} showScaleInCopyrights={true} ref={(x) => (map = x)}>
                {/* Add a map scheme layer */}
                <YMapDefaultSchemeLayer />
                {/* Add a layer of geo objects to display the geolocation marker */}
                <YMapDefaultFeaturesLayer />
                {/* Using YMapControls you can change the position of the control */}
                <YMapControls position="right">
                    {/* Add the geolocation control to the map */}
                    <YMapGeolocationControl {...COMMON_LOCATION_PARAMS} />
                </YMapControls>
                {/* Create Info Message */}
                <YMapControls position="top left">
                    <InfoMessageR text="Click on the button on the right side" />
                </YMapControls>
            </YMap>
        );
    }

    ReactDOM.render(
        <React.StrictMode>
            <App />
        </React.StrictMode>,
        document.getElementById('app')
    );
}
