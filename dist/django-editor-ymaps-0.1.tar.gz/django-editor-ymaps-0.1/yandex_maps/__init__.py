# coding: utf-8
"""
    Creating and editing Yandex maps.
"""

__author__ = 'genkosta'
__version__ = '0.1'
default_app_config = 'yandex_maps.apps.YandexMapsConfig'
