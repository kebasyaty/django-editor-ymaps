import {LOCATION} from '../variables';

window.map = null;

main();
async function main() {
    // For each object in the JS API, there is a React counterpart
    // To use the React version of the API, include the module @yandex/ymaps3-reactify
    const [ymaps3React] = await Promise.all([ymaps3.import('@yandex/ymaps3-reactify'), ymaps3.ready]);
    const reactify = ymaps3React.reactify.bindTo(React, ReactDOM);
    const {YMap, YMapDefaultSchemeLayer, YMapControls, YMapScaleControl} = reactify.module(ymaps3);
    const {YMapZoomControl} = reactify.module(await ymaps3.import('@yandex/ymaps3-default-ui-theme'));
    const {useState} = React;

    function App() {
        const [location, setLocation] = useState(LOCATION);

        return (
            // You can display the map scale as part of copyrights
            <YMap location={location} showScaleInCopyrights={true} ref={(x) => (map = x)}>
                <YMapDefaultSchemeLayer />
                <YMapControls position="right">
                    <YMapZoomControl />
                </YMapControls>
                {/* Or place the scale of the map as a control anywhere on the map. */}
                <YMapControls position="bottom left">
                    <YMapScaleControl />
                </YMapControls>
            </YMap>
        );
    }

    ReactDOM.render(
        <React.StrictMode>
            <App />
        </React.StrictMode>,
        document.getElementById('app')
    );
}
