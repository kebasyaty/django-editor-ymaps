import type {LngLat, YMapLocationRequest} from '@yandex/ymaps3-types';

ymaps3.import.registerCdn('https://cdn.jsdelivr.net/npm/{package}', [
    '@yandex/ymaps3-default-ui-theme@0.0',
    '@yandex/ymaps3-context-menu@0.0'
]);

export let InfoPanelControl = null;

ymaps3.ready.then(() => {
    class InfoPanelControlClass extends ymaps3.YMapComplexEntity<{}> {
        private readonly __text = 'Click on marker with right button';

        constructor() {
            super({});
            const container = document.createElement('div');
            container.classList.add('info');

            const iconElement = document.createElement('div');
            iconElement.classList.add('icon');
            container.appendChild(iconElement);

            const textElement = document.createElement('div');
            textElement.textContent = this.__text;
            container.appendChild(textElement);

            this.addChild(new ymaps3.YMapControl({transparent: true}, container));
        }
    }
    InfoPanelControl = InfoPanelControlClass;
});
