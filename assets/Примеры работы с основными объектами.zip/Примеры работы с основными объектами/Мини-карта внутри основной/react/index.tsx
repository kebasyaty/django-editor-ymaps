import {MINIMAP_PROPS} from '../common';
import {LOCATION} from '../variables';

window.map = null;

main();
async function main() {
    const [ymaps3React] = await Promise.all([ymaps3.import('@yandex/ymaps3-reactify'), ymaps3.ready]);
    const reactify = ymaps3React.reactify.bindTo(React, ReactDOM);

    const {YMap, YMapDefaultSchemeLayer, YMapDefaultFeaturesLayer, YMapControls} = reactify.module(ymaps3);

    const {useState} = React;

    const {YMapMiniMap} = reactify.module(await ymaps3.import('@yandex/ymaps3-minimap'));

    ReactDOM.render(
        <React.StrictMode>
            <App />
        </React.StrictMode>,
        document.getElementById('app')
    );

    function App() {
        const [showBounds, setShowBounds] = useState(MINIMAP_PROPS.showBounds);

        const onChangeSyncZoom = (value: boolean) => {};
        const onChangePrevLocation = (value: boolean) => {};
        const onChangeSegment = (value: string) => {
            setShowBounds(value === 'Area moves');
        };

        return (
            <YMap location={LOCATION} ref={(x) => (map = x)}>
                <YMapDefaultSchemeLayer />
                <YMapDefaultFeaturesLayer />

                <YMapControls position="right bottom">
                    <YMapMiniMap {...MINIMAP_PROPS} showBounds={showBounds} />
                </YMapControls>
            </YMap>
        );
    }
}
