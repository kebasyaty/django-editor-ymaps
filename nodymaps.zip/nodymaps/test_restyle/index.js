'use strict';

global.console.log('Hello World!');
