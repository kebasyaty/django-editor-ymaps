import {LOCATION, BOUNDS, NAMES, getImageSrc} from '../variables';
import {COMMON_LOCATION_PARAMS, ExpandedFeature, getBounds, getRandomPoints, MARGIN} from '../common';

window.map = null;

async function main() {
    const [ymaps3Vue] = await Promise.all([ymaps3.import('@yandex/ymaps3-vuefy'), ymaps3.ready]);
    const vuefy = ymaps3Vue.vuefy.bindTo(Vue);
    const {YMap, YMapDefaultSchemeLayer, YMapDefaultFeaturesLayer, YMapMarker} = vuefy.module(ymaps3);
    // Load the package with the cluster, extract the classes for creating clusterer objects and the clustering method
    const {YMapClusterer, clusterByGrid} = vuefy.module(await ymaps3.import('@yandex/ymaps3-clusterer'));

    const Marker = Vue.defineComponent({
        props: ['feature'],
        components: {
            YMapMarker
        },
        setup(props) {
            const visible = Vue.ref(false);
            const imgPath = getImageSrc(props.feature.id);

            return {
                imgPath,
                visible,
                NAMES
            };
        },
        template: `
      <YMapMarker iconName="landmark" :key="feature.id" :coordinates="feature.geometry.coordinates">
        <div
          class="marker-container"
          @mouseover="() => visible = true"
          @mouseout="() => visible = false"
        >
          <div :class="[visible ? 'visible' : 'hidden', 'marker-text']">{{ NAMES[feature.id] }}</div>
          <div class="marker">
            <img alt="img" class="image" :src="imgPath"/>
          </div>
        </div>
      </YMapMarker>
    `
    });

    const Cluster = Vue.defineComponent({
        props: {
            coordinates: Array,
            features: Array,
            onClick: Function
        },
        components: {
            YMapMarker
        },
        template: `
      <YMapMarker
        :coordinates="coordinates"
        :onClick="onClick"
      >
        <div class="circle">
          <div class="circle-content">
            <span class="circle-text">{{features.length}}</span>
          </div>
        </div>
      </YMapMarker>
    `
    });

    const App = Vue.createApp({
        components: {
            YMap,
            YMapDefaultSchemeLayer,
            YMapDefaultFeaturesLayer,
            YMapClusterer,
            Cluster,
            Marker
        },
        setup() {
            const refMap = (ref) => {
                window.map = ref?.entity;
            };
            const location = Vue.ref(LOCATION);

            const gridSizedMethod = clusterByGrid({gridSize: 64});
            const points = getRandomPoints(BOUNDS);

            const onClusterClick = (features: ExpandedFeature[]) => {
                const bounds = getBounds(features.map((feature: ExpandedFeature) => feature.geometry.coordinates));
                location.value = {bounds, ...COMMON_LOCATION_PARAMS};
            };

            return {
                MARGIN,
                refMap,
                location,
                gridSizedMethod,
                points,
                onClusterClick
            };
        },
        template: `
      <YMap :margin="MARGIN" :location="location" :showScaleInCopyrights="true" :ref="refMap">
        <!-- Add a map scheme layer -->
        <YMapDefaultSchemeLayer />
        <!-- Add default features layer -->
        <YMapDefaultFeaturesLayer />
        <!-- In the clusterer props, we pass the previously declared functions for rendering markers and clusters,
        the clustering method, and an array of features -->
        <YMapClusterer :method="gridSizedMethod" :features="points">
          <template #marker="{feature}">
            <Marker :feature="feature" />
          </template>
          <template #cluster="{coordinates, features}">
            <Cluster :onClick="() => onClusterClick(features)" :coordinates="coordinates" :features="features" />
          </template>
        </YMapClusterer>
      </YMap>
    `
    });

    App.mount('#app');
}

main();
