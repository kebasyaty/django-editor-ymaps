import {LOCATION} from '../variables';
import {Position, VerticalTriggerPosition, HorizontalTriggerPosition} from '@yandex/ymaps3-drawer-control';
import {
    subscribePositionClick,
    subscribeHorizontalTriggerPositionClick,
    subscribeVerticalTriggerPositionClick
} from '../common';

window.map = null;

main();
async function main() {
    const [ymaps3Vue] = await Promise.all([ymaps3.import('@yandex/ymaps3-vuefy'), ymaps3.ready]);
    const vuefy = ymaps3Vue.vuefy.bindTo(Vue);

    const {YMap, YMapDefaultSchemeLayer, YMapDefaultFeaturesLayer} = vuefy.module(ymaps3);

    const {YMapDrawerControl} = vuefy.module(await ymaps3.import('@yandex/ymaps3-drawer-control'));

    const app = Vue.createApp({
        components: {
            YMap,
            YMapDefaultSchemeLayer,
            YMapDefaultFeaturesLayer,
            YMapDrawerControl
        },
        setup() {
            const refMap = (ref) => {
                window.map = ref?.entity;
            };
            const open = Vue.ref(true);
            const position = Vue.ref<Position>('left');
            const verticalTriggerPosition = Vue.ref<VerticalTriggerPosition>('center');
            const horizontalTriggerPosition = Vue.ref<HorizontalTriggerPosition>('center');

            subscribePositionClick((newPosition) => {
                position.value = newPosition;
            });

            subscribeHorizontalTriggerPositionClick((position) => {
                horizontalTriggerPosition.value = position;
            });
            subscribeVerticalTriggerPositionClick((position) => {
                verticalTriggerPosition.value = position;
            });

            const onOpenChange = (value: boolean) => {
                open.value = !value;
            };

            return {LOCATION, refMap, open, position, verticalTriggerPosition, horizontalTriggerPosition, onOpenChange};
        },
        template: `
            <YMap :location="LOCATION" :ref="refMap">
                <YMapDefaultSchemeLayer />

                <YMapDefaultFeaturesLayer />

                <YMapDrawerControl
                    :onOpenChange="onOpenChange"
                    :position="position"
                    :verticalTriggerPosition="verticalTriggerPosition"
                    :horizontalTriggerPosition="horizontalTriggerPosition"
                    :open="open">
                    <template #content>
                        <div class="drawer-content">
                            <h1>Good day, Sir!</h1>
                            <span>I am a sidebar :)</span>
                        </div>
                    </template>
                </YMapDrawerControl>
            </YMap>`
    });
    app.mount('#app');
}
