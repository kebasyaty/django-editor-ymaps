<template>
  <v-tooltip bottom>
    <template #activator="{ on }">
      <svg
        v-on="on"
        :class="classes"
        xmlns="http://www.w3.org/2000/svg"
        :width="computedWidth"
        :height="height"
        :viewBox="computedViewBox"
        :aria-labelledby="iconName"
        role="presentation"
      >
        <path
          d="m18 16.819c1.494 0.6348 2.4 1.4676 2.4 2.3808 0 1.9884-4.2984 3.6-9.6 3.6s-9.6-1.6116-9.6-3.6c0-0.912 0.906-1.7472 2.4-2.3808"
          fill="none"
          :stroke="color"
          stroke-linecap="round"
          stroke-linejoin="round"
          stroke-width="2.4"
        />
        <path
          d="m9.9144 18.81 0.8856-0.81zm1.7712 0 6e-3 -6e-3 0.0144-0.0168 0.054-0.06 0.1992-0.2232a45.828 45.828 0 0 0 2.8176-3.5484c0.7704-1.08 1.56-2.304 2.1612-3.5196 0.588-1.188 1.062-2.4948 1.062-3.7032 0-4.2876-3.1416-7.7328-7.2-7.7328s-7.2 3.444-7.2 7.7328c0 1.2084 0.474 2.5152 1.062 3.7032 0.6012 1.2156 1.392 2.4396 2.16 3.5196a45.784 45.784 0 0 0 3.018 3.7716l0.054 0.06 0.0144 0.0168 6e-3 6e-3a1.2 1.2 0 0 0 1.7712 0zm-0.8856-0.81 0.8856 0.8088zm0-13.2a2.4 2.4 0 1 0 0 4.8 2.4 2.4 0 0 0 0-4.8z"
          clip-rule="evenodd"
          fill-rule="evenodd"
          stroke-width="1.2"
          :fill="color"
        />
      </svg>
    </template>
    <span>{{ description }}</span>
  </v-tooltip>
</template>

<script>
export default {
  name: "IconLogo",
  props: {
    iconName: {
      type: String,
      default: "DjEYM",
    },
    classes: {
      type: String,
      default: "",
    },
    height: {
      type: [Number, String],
      default: 64,
    },
    color: {
      type: String,
      default: "currentColor",
    },
  },
  data: () => ({
    drawer: null,
    viewBox: [0, 0, 21.6, 24],
  }),
  computed: {
    description() {
      const name = this.iconName;
      return (
        name[0].toLocaleUpperCase() +
        name.slice(1) +
        " - " +
        this.$t("message.1")
      );
    },
    computedViewBox() {
      return this.viewBox.join(" ");
    },
    computedWidth() {
      const height = this.height.toString();
      const unit = height.match(
        /px|%|em|ex|cm|mm|in|pt|pc|ch|rem|vh|vw|vmin|vmax$/,
      );
      return (
        Math.ceil(this.viewBox[2] * (parseFloat(height) / this.viewBox[3])) +
        (unit ? unit[0] : "")
      );
    },
  },
};
</script>
