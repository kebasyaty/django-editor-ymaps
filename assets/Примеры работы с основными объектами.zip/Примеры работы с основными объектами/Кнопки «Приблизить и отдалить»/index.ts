import {LOCATION} from '../variables';

window.map = null;

main();
async function main() {
    // Waiting for all api elements to be loaded
    await ymaps3.ready;
    const {YMap, YMapDefaultSchemeLayer, YMapControls, YMapScaleControl} = ymaps3;
    const {YMapZoomControl} = await ymaps3.import('@yandex/ymaps3-default-ui-theme');

    // Initialize the map
    map = new YMap(
        document.getElementById('app'),
        {
            location: LOCATION,
            showScaleInCopyrights: true // You can display the map scale as part of copyrights
        },
        [new YMapDefaultSchemeLayer({})]
    );

    // Or place the scale of the map as a control anywhere on the map
    const controls = new YMapControls({position: 'bottom left'}, [new YMapScaleControl({})]);
    map.addChild(controls);

    map.addChild(new YMapControls({position: 'right'}).addChild(new YMapZoomControl({})));
}
