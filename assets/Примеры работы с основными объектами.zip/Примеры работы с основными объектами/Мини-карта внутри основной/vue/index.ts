import {MINIMAP_PROPS} from '../common';
import {LOCATION} from '../variables';

window.map = null;

main();
async function main() {
    const [ymaps3Vue] = await Promise.all([ymaps3.import('@yandex/ymaps3-vuefy'), ymaps3.ready]);
    const vuefy = ymaps3Vue.vuefy.bindTo(Vue);

    const {YMap, YMapDefaultSchemeLayer, YMapDefaultFeaturesLayer, YMapControls} = vuefy.module(ymaps3);

    const {YMapMiniMap} = vuefy.module(await ymaps3.import('@yandex/ymaps3-minimap'));

    const app = Vue.createApp({
        components: {
            YMap,
            YMapDefaultSchemeLayer,
            YMapDefaultFeaturesLayer,
            YMapControls,
            YMapMiniMap
        },
        setup() {
            const refMap = (ref) => {
                window.map = ref?.entity;
            };

            return {MINIMAP_PROPS, LOCATION, refMap};
        },
        template: `
            <YMap :location="LOCATION" :ref="refMap">
                <YMapDefaultSchemeLayer />
                <YMapDefaultFeaturesLayer />
                <YMapControls position="right bottom">
                    <YMapMiniMap v-bind="MINIMAP_PROPS" />
                </YMapControls>
            </YMap>`
    });
    app.mount('#app');
}
