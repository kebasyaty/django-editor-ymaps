import type {LngLat, YMapLocationRequest} from '@yandex/ymaps3-types';

ymaps3.import.registerCdn('https://cdn.jsdelivr.net/npm/{package}', [
    '@yandex/ymaps3-default-ui-theme@0.0',
    '@yandex/ymaps3-signpost@0.0'
]);
