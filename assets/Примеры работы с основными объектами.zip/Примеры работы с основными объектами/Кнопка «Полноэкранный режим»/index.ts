import {LOCATION} from '../variables';

window.map = null;

main();

async function main() {
    // Waiting for all api elements to be loaded
    await ymaps3.ready;
    const {YMap, YMapDefaultSchemeLayer, YMapControls, YMapControl, YMapComplexEntity} = ymaps3;
    // Initialize the map
    map = new YMap(
        // Pass the link to the HTMLElement of the container
        document.getElementById('app'),
        // Pass the map initialization parameters
        {location: LOCATION, showScaleInCopyrights: true},
        // Add a map scheme layer
        [new YMapDefaultSchemeLayer({})]
    );

    // Add a container for YMapControlButton and add it to the map
    const controls = new YMapControls({position: 'top right'});
    map.addChild(controls);

    function fullScreenBtnHandler() {
        // The document.fullscreenElement returns the Element that is currently being presented in fullscreen mode in this document, or null if fullscreen mode is not currently in use
        if (document.fullscreenElement) {
            // The document.exitFullscreen() requests that the element on this document which is currently being presented in fullscreen mode be taken out of fullscreen mode
            document.exitFullscreen();
        } else {
            // The element.requestFullscreen() method issues an asynchronous request to make the element be displayed in fullscreen mode
            map.container.requestFullscreen();
        }
    }

    class FullscreenButton extends YMapComplexEntity<{}> {
        private _element: HTMLButtonElement;

        private _detachDom: () => void;

        // Method for create a DOM control element
        _createElement() {
            // Create an div element that will be passed to the YMapControlButton
            const fullScreenButtonElement = document.createElement('button');
            fullScreenButtonElement.type = 'button';
            fullScreenButtonElement.onclick = fullScreenBtnHandler;
            fullScreenButtonElement.classList.add('button', 'fullscreen');

            // The fullscreenchange event is fired immediately after the browser switches into or out of fullscreen mode
            document.addEventListener('fullscreenchange', function () {
                fullScreenButtonElement.classList.toggle('exit-fullscreen');
            });

            return fullScreenButtonElement;
        }

        // Method for attaching the control to the map
        _onAttach() {
            this._element = this._createElement();
            this._detachDom = ymaps3.useDomContext(this, this._element, this._element);
        }

        // Method for detaching control from the map
        _onDetach() {
            this._detachDom();
            this._detachDom = null;
            this._element = null;
        }
    }

    // Add YMapControlButton that will enable or disable fullscreen mode
    const fullScreenBtn = new YMapControl();
    fullScreenBtn.addChild(new FullscreenButton({}));

    controls.addChild(fullScreenBtn);
}
