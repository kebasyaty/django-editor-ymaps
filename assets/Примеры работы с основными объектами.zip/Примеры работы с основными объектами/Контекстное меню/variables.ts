import type {LngLat, YMapLocationRequest} from '@yandex/ymaps3-types';

export const MARKER_LOCATION: LngLat = [37.623082, 55.75254];
export const LOCATION: YMapLocationRequest = {
    center: [37.623082, 55.75254], // starting position [lng, lat]
    zoom: 9 // starting zoom
};
