import type {LngLat} from '@yandex/ymaps3-types';
import {BOUNDS, getImageSrc, LOCATION, NAMES} from '../variables';
import {COMMON_LOCATION_PARAMS, type ExpandedFeature, getBounds, getRandomPoints, MARGIN} from '../common';

window.map = null;

main();
async function main() {
    // For each object in the JS API, there is a React counterpart
    // To use the React version of the API, include the module @yandex/ymaps3-reactify
    const [ymaps3React] = await Promise.all([ymaps3.import('@yandex/ymaps3-reactify'), ymaps3.ready]);
    const reactify = ymaps3React.reactify.bindTo(React, ReactDOM);
    const {YMap, YMapDefaultSchemeLayer, YMapDefaultFeaturesLayer, YMapMarker} = reactify.module(ymaps3);
    // Load the package with the cluster, extract the classes for creating clusterer objects and the clustering method
    const {YMapClusterer, clusterByGrid} = reactify.module(await ymaps3.import('@yandex/ymaps3-clusterer'));

    const {useState, useCallback, useMemo} = React;

    function App() {
        const [location, setLocation] = useState(LOCATION);
        const [hoverMarkers, setHoverMarkers] = useState({});
        const points = useMemo(() => getRandomPoints(BOUNDS), []);

        // We declare a render function. For the clustering method, we pass and store the size of one grid division in pixels
        const gridSizedMethod = useMemo(() => clusterByGrid({gridSize: 64}), []);

        const markerMouseOver = useCallback((id: string) => {
            setHoverMarkers((state) => ({
                ...state,
                [id]: true
            }));
        }, []);

        const markerMouseOut = useCallback((id: string) => {
            setHoverMarkers((state) => ({
                ...state,
                [id]: false
            }));
        }, []);

        const onClusterClick = useCallback(
            (features: ExpandedFeature[]) => {
                const bounds = getBounds(features.map((feature: ExpandedFeature) => feature.geometry.coordinates));
                setLocation((prevLocation) => ({...prevLocation, bounds, ...COMMON_LOCATION_PARAMS}));
            },
            [location]
        );

        // We declare a function for rendering markers. Note that the function must return any Entity element. In the example, this is YMapDefaultMarker
        const marker = (feature: ExpandedFeature) => (
            <YMapMarker coordinates={feature.geometry.coordinates}>
                <div
                    className="marker-container"
                    onMouseOver={() => markerMouseOver(feature.id)}
                    onMouseOut={() => markerMouseOut(feature.id)}
                >
                    <div className={`marker-text ${hoverMarkers[feature.id] ? 'visible' : 'hidden'}`}>
                        {NAMES[feature.id]}
                    </div>
                    <div className="marker">
                        <img alt="img" className="image" src={getImageSrc(feature.id)} />
                    </div>
                </div>
            </YMapMarker>
        );

        // We declare a cluster rendering function that also returns an Entity element. We will transfer the marker and cluster rendering functions to the clusterer settings
        const cluster = (coordinates: LngLat, features: ExpandedFeature[]) => (
            <YMapMarker onClick={() => onClusterClick(features)} coordinates={coordinates}>
                <div className="circle">
                    <div className="circle-content">
                        <span className="circle-text">{features.length}</span>
                    </div>
                </div>
            </YMapMarker>
        );

        return (
            // Initialize the map and pass initialization parameters
            <YMap margin={MARGIN} location={location} showScaleInCopyrights={true} ref={(x) => (map = x)}>
                {/* Add a map scheme layer */}
                <YMapDefaultSchemeLayer />
                {/* Add clusterer data sources */}
                <YMapDefaultFeaturesLayer />
                {/* In the clusterer props, we pass the previously declared functions for rendering markers and clusters,
                the clustering method, and an array of features */}
                <YMapClusterer marker={marker} cluster={cluster} method={gridSizedMethod} features={points} />
            </YMap>
        );
    }

    ReactDOM.render(
        <React.StrictMode>
            <App />
        </React.StrictMode>,
        document.getElementById('app')
    );
}
