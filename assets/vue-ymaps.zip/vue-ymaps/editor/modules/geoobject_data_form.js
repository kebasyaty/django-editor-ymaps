/*
 * Module for the GeoobjectDataForm.vue component.
 */

export default {
  namespaced: true,
  state: {
    header: "",
    body: null,
    footer: "",
  },
  getters: {},
  mutations: {
    setHeader(state, text) {
      state.header = text;
    },
    setBody(state, file) {
      state.body = file;
    },
    setFooter(state, text) {
      state.footer = text;
    },
  },
  actions: {
    restoreDefaults({ state }) {
      state.header = "";
      state.body = null;
      state.footer = "";
    },
  },
};
