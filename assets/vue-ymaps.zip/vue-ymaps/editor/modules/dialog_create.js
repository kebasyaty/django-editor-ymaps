/*
 * Module for the MenuCreateGeoobject.vue component.
 */

import helpers from "@/helpers.js";

export default {
  namespaced: true,
  state: {
    coords: [0, 0],
  },
  getters: {},
  mutations: {
    setLatitude(state, coord) {
      state.coords[0] = helpers.roundCoord(coord);
    },
    setLongitude(state, coord) {
      state.coords[1] = helpers.roundCoord(coord);
    },
  },
  actions: {
    // Open geoobjectDialogShow for Route or Territory.
    actionCreateNewGeoobjecte({ commit, dispatch, rootState }, payload) {
      commit(
        "modals/geoobjectDialogShow",
        {
          title: payload.title,
          editBtn: true,
          saveBtn: payload.showSaveBtn,
          cancelBtn: true,
          deleteBtn: false,
          actionBtnEdit: () => {
            if (!rootState[payload.storeModuleName].category) {
              commit(
                "modals/alertSnackbarShow",
                payload.messageErrorAddCategory(),
                { root: true },
              );
              return;
            }
            if (rootState[payload.storeModuleName].header.length === 0) {
              commit(
                "modals/alertSnackbarShow",
                payload.messageErrorAddHeader(),
                { root: true },
              );
              return;
            }
            commit("modals/alertSnackbarClose", null, { root: true });
            commit("modals/geoobjectDialogClose", null, { root: true });
          },
          actionBtnSave: () => {
            if (!rootState[payload.storeModuleName].category) {
              commit(
                "modals/alertSnackbarShow",
                payload.messageErrorAddCategory(),
                { root: true },
              );
              return;
            }
            if (rootState[payload.storeModuleName].header.length === 0) {
              commit(
                "modals/alertSnackbarShow",
                payload.messageErrorAddHeader(),
                { root: true },
              );
              return;
            }
            commit(
              "setDataAction",
              { geoType: payload.geoType, actionType: "save" },
              { root: true },
            );
            dispatch("ajaxContextMenu", null, { root: true });
          },
          actionBtnCancel: () => {
            if (rootState.ymap.editableGeoobject !== null) {
              rootState.ymap.Map.geoobjects.remove(
                rootState.ymap.editableGeoobject,
              );
            }
            commit("ymap/setEditableGeoobject", null, { root: true });
            dispatch(`${payload.storeModuleName}/restoreDefaults`, null, {
              root: true,
            });
            commit("modals/alertSnackbarClose", null, { root: true });
            commit("modals/geoobjectDialogClose", null, { root: true });
          },
          actionBtnDelete: null,
          componentHeatPoint: false,
          componentPlacemark: false,
          componentPolyline: payload.geoType === "polyline",
          componentPolygon: payload.geoType === "polygon",
          // componentPolygon: payload.geoType === 'polygon'
        },
        { root: true },
      );
    },
  },
};
